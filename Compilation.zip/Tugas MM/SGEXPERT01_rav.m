a = 200;
b = 100;
tambah = a + b;
kurang = a - b;
kali = a * b;
bagi = a / b;