A = [ 10 40; 20 30]
B = [ 40 50; 20 30]

tambah = A + B;
kurang = A - B;
kali = A * B;
skalar = A * 2;