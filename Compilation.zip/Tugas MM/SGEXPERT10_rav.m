%convert binary number
%user input dan di convert oleh program

biner = input('Input bilangan biner : ', 's');
b = bin2dec(biner);
disp('Hasil convert dari bilangan yang anda inputkan adalah');
disp(b);



